var searchData=
[
  ['clearalarms',['clearAlarms',['../classDS3231.html#ad402ba1ca960dd1d1da5fc68d806696e',1,'DS3231']]],
  ['connectdevice',['connectDevice',['../classI2CDevice.html#a97ce3e695080f667e4acfa4c6fe82ba4',1,'I2CDevice']]]
];
