var searchData=
[
  ['writedate',['writeDate',['../classDS3231.html#aa8b6b1279d7f7e04cd4a3797d620cf61',1,'DS3231']]],
  ['writetime',['writeTime',['../classDS3231.html#a8780408536a9eedfe2f04d4085a103b0',1,'DS3231']]],
  ['writetoreg',['writeToReg',['../classI2CDevice.html#a390fcd7a411fbc92509a69c1d04660a2',1,'I2CDevice']]]
];
