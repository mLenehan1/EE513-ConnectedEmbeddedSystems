# EE513 - Connected Embedded Systems: Assignment 1

This assignment focuses on interfacing a DS3231 RTC with an embedded linux
device - in my case, a Raspberry Pi 3 B+.
